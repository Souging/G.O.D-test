# Security Policy

## Supported Versions

Due to the nature of the fast development that is happening in this project, only the latest released version can be supported.

## Reporting a Vulnerability

If you find a vulnerability, please contact us on  [Discord](https://discord.gg/xcu3ECkH9a) rather than creating a GitHub issue to allow us some time to fix it before it is a known vulnerability to others.
