# RedPajama 3B preview release

```shell
accelerate launch scripts/finetune.py examples/redpajama/config-3b.yml

```
