# MPT-7B

```shell
accelerate launch scripts/finetune.py examples/mpt-7b/config.yml

```
