# Grokfast Optimizer

See https://github.com/ironjr/grokfast

### Usage

```yaml
plugins:
  - axolotl.integrations.grokfast.GrokfastPlugin

grokfast_alpha: 2.0
grokfast_lamb: 0.98
```
